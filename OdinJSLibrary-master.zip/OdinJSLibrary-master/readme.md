This is part of The Odin Project's Course, in the JavaScript track.
 //Made by catiesai