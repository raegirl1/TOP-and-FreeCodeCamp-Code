// Your web app's Firebase configuration
var firebaseConfig = {
	apiKey: 'AIzaSyA-mIFot3xBRylp1GDK6bhPCl_h7xzGbU4',
	authDomain: 'test-library-db51d.firebaseapp.com',
	databaseURL: 'https://test-library-db51d.firebaseio.com',
	projectId: 'test-library-db51d',
	storageBucket: 'test-library-db51d.appspot.com',
	messagingSenderId: '188502819402',
	appId: '1:188502819402:web:cab49dc199c3e78eda1cb3'
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
