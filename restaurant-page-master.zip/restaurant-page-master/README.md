TOP practice project

[Preview](https://raegirl1.github.io/restaurant-page/)
