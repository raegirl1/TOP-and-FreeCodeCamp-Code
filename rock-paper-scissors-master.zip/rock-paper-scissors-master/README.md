# rock-paper-scissors

First JavaScript project ever! 
With http://theodinproject.com.

UI design inspired by Jonas Schmedtmann.
